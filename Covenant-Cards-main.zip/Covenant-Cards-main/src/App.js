export default function App() {
  return (
    <div className="bg-blue-500 text-white p-8 text-center">
      <h1 className="text-3xl font-bold">Hello TailwindCSS!</h1>
      <p className="mt-4">If you see this, TailwindCSS is working!</p>
    </div>
  );
}


