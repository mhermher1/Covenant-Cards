module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html'], // Scan your files
  theme: {
    extend: {}, // Optional customization
  },
  plugins: [], // Optional plugins
};



